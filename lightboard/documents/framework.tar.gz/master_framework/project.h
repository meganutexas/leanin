//project.h

#ifndef INCLUDED_PROJECT
#define INCLUDED_PROJECT

//put headers related to project functions here
void conductor_start();
void axel_f();
void rest(int mult);

void pulse(int mult, const struct CRGB& color);

#endif // INCLUDED_PROJECT
