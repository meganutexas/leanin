#include <stdio.h>
 
main() {
  printf(“hello, world\n”);
}

/* ---------------------------- */

#include <stdio.h>
 
main() {
  printf(“hello, “);
	printf(“world”);
	printf(‘\n”);
}

